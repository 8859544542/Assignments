package com.cg.assignment.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.cg.assignment.beans")
public class ApplicationConfig {
	
}
