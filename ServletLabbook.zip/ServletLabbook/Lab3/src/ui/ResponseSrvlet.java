package ui;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.DatabaseConnection;

/**
 * Servlet implementation class ResponseSrvlet
 */
@WebServlet("/ResponseSrvlet")
public class ResponseSrvlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ResponseSrvlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		int id =Integer.parseInt(req.getParameter("id"));
		String tname=req.getParameter("tname");
		int seat=Integer.parseInt(req.getParameter("seats"));
		PrintWriter out = resp.getWriter();
		if(seat==0) {
			out.print("<b>No Seats Are Available.</b>");
			out.print("</br></br><a href='index.html'>Enroll Again</a>");
		}
		else{
			try {
				
				
				Statement stmt=new DatabaseConnection().getStatement();
				ResultSet rs=stmt.executeQuery("update trainingdata set available_seat="+(seat-1)+" where training_id="+id);
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
			out.print("<b>Hi you have successfully enrolled for "+tname+" Training.</b>");
			out.print("</br></br><a href='index.html'>Enroll Again</a>");
	}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
