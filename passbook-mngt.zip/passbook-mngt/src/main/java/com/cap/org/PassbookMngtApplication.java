package com.cap.org;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PassbookMngtApplication {

	public static void main(String[] args) {
		SpringApplication.run(PassbookMngtApplication.class, args);
		System.out.println("its working ");
	}

}
