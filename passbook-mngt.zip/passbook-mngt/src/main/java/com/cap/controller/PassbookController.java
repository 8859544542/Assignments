package com.cap.controller;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cap.dto.TransactionDetailDto;
import com.cap.entities.Transaction;
import com.cap.service.IPassbookService;

@RestController
@RequestMapping("/transactions")
public class PassbookController {
	
	@Autowired
	private IPassbookService service;
	
	
	  @GetMapping("/get/{transAccountId}")
	    public ResponseEntity<TransactionDetailDto> add(@PathVariable("transAccountId") String id) {
	      List<Transaction> list=service.getAllTransactions(id);
	        TransactionDetailDto dto = convertToDetailsDto((Transaction) list);
	        ResponseEntity<TransactionDetailDto> response = new ResponseEntity<>(dto, HttpStatus.OK);
	        return response;
	    }

	  List<TransactionDetailDto> convertToDetails(Collection<Transaction> transactions) {
	        List<TransactionDetailDto> dtos = new ArrayList<>();
	        for (Transaction transaction : transactions) {
	        	TransactionDetailDto dto = convertToDetailsDto(transaction);
	            dtos.add(dto);
	        }
	        return dtos;
	    }

	  TransactionDetailDto convertToDetailsDto(Transaction transaction) {
	    	TransactionDetailDto dto = new TransactionDetailDto();
	        dto.setTransAmount(transaction.getTransAmount());
	        dto.setTransOption(transaction.getTransOption());
	        dto.setTransTo(transaction.getTransTo());
	        dto.setTransDate(transaction.getTransDate());
	        dto.setTransClosingBalance(transaction.getTransClosingBalance());
	        return dto;
	    }
}
