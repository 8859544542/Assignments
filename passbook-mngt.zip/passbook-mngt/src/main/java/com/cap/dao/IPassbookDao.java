package com.cap.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cap.entities.Transaction;

public interface IPassbookDao extends JpaRepository<Transaction, String>{

}
