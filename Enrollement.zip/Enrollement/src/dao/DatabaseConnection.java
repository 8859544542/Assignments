package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;

public class DatabaseConnection {

	private Connection con;
	private Statement stmt;
	private ResultSet rs;
	private PreparedStatement ps;
	
	public DatabaseConnection() {
		try{  
 
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","DATABASE01","password");   
			stmt=con.createStatement();     
			  
			}catch(Exception e){
				System.out.println(e);
			}  
			  
	}
	
	public ResultSet getALlTrainingDetails() {
		String query="Select * from TrainingData";
		
		try {
			rs = stmt.executeQuery(query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return rs;
	}
	public Statement getStatement() {
		
		return stmt;
	}
				
	}

