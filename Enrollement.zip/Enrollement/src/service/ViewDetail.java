package service;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.DatabaseConnection;

/**
 * Servlet implementation class ViewDetail
 */
@WebServlet("/ViewDetail")
public class ViewDetail extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public ViewDetail() {
        super();
       
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
         PrintWriter out = response.getWriter();
		 try {
			ResultSet rs=new DatabaseConnection().getALlTrainingDetails();
			out.print("<table>");
			out.print("<tr>");
			out.print("<th>Training Id</th>"); 
			out.print("<th>Training Name</th>"); 
			out.print("<th>Avalaible Seats</th>"); 
			out.print("</tr>");
			while(rs.next()) { 
				out.print("<tr>");
				out.print("<td>"+rs.getInt(1)+"</td><td>"+rs.getString(2)+"</td><td>"+rs.getInt(3)+"</td><td><a href='ResponseSrvlet?id="+rs.getInt(1)+"&tname="+rs.getString(2)+"&seats="+rs.getInt(3)+"'>Enroll</a></td>"); 
				out.print("</tr>");
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
